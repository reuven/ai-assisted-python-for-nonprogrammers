In this exercise, you will implement a very simple game, one that will reinforce some of the ideas you've been learning about working with numbers.

Here's how the game should work:

* Define a variable, `number`, with the number that the user needs to guess. It should be an integer between 0 and 100.
* Ask the user to guess the number. Assign the guess to the variable `guess`.
* Give one of three responses:
** You got it!
** Too low
** Too high

Note that the user will only have one chance to guess the number. After that one guess, the game is over.
