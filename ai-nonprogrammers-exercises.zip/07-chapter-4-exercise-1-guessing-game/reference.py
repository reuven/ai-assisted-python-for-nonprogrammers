number = 72

guess = input('Guess the number: ')
guess = int(guess)

if guess == number:
    print(f'You got it!')
elif guess < number:
    print(f'Too low!')
else:
    print(f'Too high!')
