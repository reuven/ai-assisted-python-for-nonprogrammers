In this exercise, you'll analyze a text file, producing a report for the user on a variety of aspects of the file.

Ask the user to enter the name of a text file. Iterate over the file, one line at a time. Along the way, keep track of:

* Number of blank lines (i.e., containing only a `'\n'` character)
* Number of capitalized words
* Number of numbers (i.e., words that only contain digits 0-9)
* Number of punctuation marks (i.e., `'.'`, `'?'`, and `'!'`)
* Number of words that start and end with the same letter (ignoring case)

Keep track of these in the `analysis` dict, which you'll set up before opening and iterating over the file. After reading through the file, print each key-value in `analysis`.
