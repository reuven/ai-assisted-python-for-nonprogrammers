filename = input('Enter filename: ').strip()

f = open(filename)

analysis = {'blank_lines': 0,
            'cap_words': 0,
            'numbers': 0,
            'punctuation': 0,
            'same_start_end': 0}

for one_line in f:
    if one_line.strip() == '':
        analysis['blank_lines'] += 1

    for one_word in one_line.split():
        if one_word == one_word.capitalize():
            analysis['cap_words'] += 1

        if one_word.lower()[0] == one_word.lower()[-1]:
            analysis['same_start_end'] += 1

        if one_word.isdigit():
            analysis['numbers'] += 1

    for one_character in one_line:
        if one_character in '.?!':
            analysis['punctuation'] += 1

f.close()

for key, value in analysis.items():
    print(f'{key}: {value}')
