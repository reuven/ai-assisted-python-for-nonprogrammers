In this game, the user needs to correctly choose a randomly selected name from a list.


Here's what you have to do for this exercise:

* Define a list of names (strings), `names`. (For example, you might define it to be the list of planets, or of people in your family.)
* Use `random.choice` to select one name at random. Assign it to `secret`.
* Define an empty list, `already_guessed`.
* Define `guess_counter` to be the integer 1. This will count how many guesses the user needed to find the secret value.
* With those in place, repeatedly ask the user to guess a name.
** If they guess the secret name, stop asking and report how many guesses it took.
** If they guess a name that is _not_ in `names`, then scold them and let them try again.
** If they guess a name that they have already tried (and is thus in `already_guessed`), then scold them, and let them try again.
** If they guess a name that is in `names`, but isn't `secret`, then add that name to `already_guessed` and increment `guess_counter`.
