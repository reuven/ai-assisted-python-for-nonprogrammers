import random

names = ['Mercury', 'Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn',
         'Uranus', 'Neptune']
secret = random.choice(names)
already_guessed = []
guess_counter = 1

while True:
    guess = input('Enter guess: ').strip()
    if guess == secret:
        print(f'You guessed {secret} in {guess_counter} guesses!')
        break

    if guess in already_guessed:
        print(f'You guessed {guess} already; try again')
        continue

    if guess not in names:
        print(f'{guess} is not a legal guess; try again')
        continue

    print(f'Sorry, but {guess} is not the secret name.')
    already_guessed.append(guess)
    guess_counter += 1

print(f'You guessed {secret}. Guesses needed: {guess_counter}')
