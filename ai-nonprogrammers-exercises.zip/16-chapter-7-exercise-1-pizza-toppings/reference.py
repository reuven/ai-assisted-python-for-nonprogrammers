total = 10
toppings = {'onion':1, 'garlic':1, 'extra cheese':3,
            'eggplant':2, 'mushrooms':2}
added_toppings = []

while len(added_toppings) < 3:
    order = input('Enter topping: ').strip()

    if order == '':
        break

    if order in toppings:
        price = toppings[order]
        total += price
        added_toppings.append(order)

        print(f'{order} costs {price}; total is now {total}')
        print(f'Current toppings: {', '.join(added_toppings)}')
    else:
        print(f'Sorry, but {order} is not a valid topping. Try again.')

print(f'Total = {total}')
print(f'Toppings = {', '.join(added_toppings)}')
