. Define a dictionary, `toppings`, in which the keys are strings (the names of available toppings) and the values are integers (the price for each topping).
. Define a variable, `total`, which starts with the base price of the pizza -- $10, in our example.
. Define an empty list, `added_toppings`, which is where we'll keep track of what toppings the user wants.
. Ask the user, repeatedly, what topping they want to add to their order.
.. If the user enters an empty string (i.e., just presses `ENTER`), then stop asking and print both the total cost and the toppings they ordered.
.. If the user enters the name of a key in `toppings`, then print the price of adding that topping, add it to `added_toppings`, and print both `total` and `added_toppings`.
.. If the user enters the name of a topping that is _not_ in `toppings`, then scold the user and let them try again.
.. If the user has chosen three toppings, then stop them from adding more, and exit from the loop.
