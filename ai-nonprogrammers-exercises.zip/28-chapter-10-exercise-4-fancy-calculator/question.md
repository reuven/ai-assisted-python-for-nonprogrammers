In this exercise, you will take the `calc` function that you wrote earlier, and change it such that two parameters (`operator`, and `second`) have default argument values. You'll then invoke the function a number of times, each passing a different combination of positional and keyword arguments.

* Modify `calc` such that two of the parameters, `operator`, and `second`, get default argument values. You can decide what those values should be.
* Now invoke `calc` a number of times, with different combinations of positional and keyword arguments. Be sure to print the result of each invocation on the screen, so that you can see how the invocation affects the result.
