def calc(first, operator='+', second=0):
    if operator == '+':
        result = first + second
    elif operator == '-':
        result = first - second
    else:
        result = '(unknown)'
    return f'{first} {operator} {second} = {result}'
