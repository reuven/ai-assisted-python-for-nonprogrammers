* Define a function, `calc`.
* When the function is invoked, it will ask the user three questions:
** To enter a first number
** To enter an operator, which should be either `+` or `-`.
** To enter a second number
* If either input isn't a number, print an error message on the screen.
* If the operator is neither `+` nor `-`, then the result should be `(unknown)`, or something similar.
* Print the original numbers and operator, along with the result, on the screen.
* Execute the function, and check that it works.

For example:

```
Enter first number: 10
Enter operator: +
Enter second number: 5

10 + 5 = 15


Enter first number: 8
Enter operator: *
Enter second number: 3

8 * 3 = (unknown)


Enter first number: hello
Enter operator: +
Enter second number: goodbye

Your input for first and/or second was not numeric.
```
