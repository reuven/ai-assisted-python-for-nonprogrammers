def calc():
    first = input('Enter first number: ').strip()
    operator = input('Enter operator: ').strip()
    second = input('Enter second number: ').strip()

    if first.isdigit() and second.isdigit():
        n1 = int(first)
        n2 = int(second)

        if operator == '+':
            result = n1 + n2
        elif operator == '-':
            result = n1 - n2
        else:
            result = '(unknown)'

        print(f'{first} {operator} {second} = {result}')

    else:
        print(f'Your input for first and/or second was not numeric.')
