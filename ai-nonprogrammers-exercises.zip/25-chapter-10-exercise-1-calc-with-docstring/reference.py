def calc(first, operator, second):
    """Perform a math operation on two numbers, and get back a
    string with the full expression.

    Expects: Three arguments:
            - first, an integer or float
            - operator, a string, either '+' or '-'
            - second, another integer or float
    Modifies: Nothing
    Returns: A string containing a math expression based on the
        numbers and operator, including the result.

    If the operator is unknown, then the result is listed as
    "(unknown)" in the returned string.

    Examples:

        calc(10, '+', 3)  # returns '10 + 3 = 13'
        calc(10, '-', 8)  # returns '10 - 8 = 2'
        calc(10, '*', 3)  # returns '10 * 3 = (unknown)'
    """

    if operator == '+':
        result = first + second
    elif operator == '-':
        result = first - second
    else:
        result = '(unknown)'
    return f'{first} {operator} {second} = {result}'
