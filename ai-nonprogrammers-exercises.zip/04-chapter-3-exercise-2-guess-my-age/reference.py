age = 55

guess = input('How old is Reuven? ')
guess = int(guess)

if guess == age:
    print('You got it!')
elif guess < age:
    print('Too low! (But thank you for the compliment)')
else:
    print('Too high! (Do I really look that old to you?)')
