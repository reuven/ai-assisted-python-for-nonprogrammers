Here's another exercise that will bring together the different topics you've been learning. This time, we'll pretend that the user is someone other than yourself, and that they have to guess your age.


Here are the parameters of the game:

* Assign your age to the variable `age`.
* Ask the user to guess how old you are.
* Print one of three answers: `too low`, `too high`, or `you got it!`
* You can assume that the user will enter an integer.
