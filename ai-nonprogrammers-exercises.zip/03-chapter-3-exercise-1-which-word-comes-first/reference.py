first = input('Enter first word: ')
second = input('Enter second word: ')

if first < second:
    print(f'{first} comes before {second}')
else:
    print(f'{second} comes before {first}')
