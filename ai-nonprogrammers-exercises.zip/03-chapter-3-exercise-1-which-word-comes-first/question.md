
Ask the user to enter two words, and assign each word to a separate variable. You can assume that the user enters two different words (i.e., not the same one), and that both words only contain lowercase letters. Tell the user which word comes first alphabetically.

For example:

```
Enter first word: marriage
Enter second word: love

love comes before marriage
```
