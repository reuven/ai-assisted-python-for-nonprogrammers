In the previous exercise, you wrote a `calc` function. That function, once invoked, asked the user to enter two numbers and an operator, and used them in the calculation. In real life, however, it's more common to simply pass such values as arguments to a function.

For this exercise, you'll update the `calc` function such that it takes three arguments -- a first number, an operator, and a second number -- instead of asking the user to enter them each time the function is invoked.

* Rewrite `calc`, such that instead of using `input` in the function body to get values for `first`, `operator`, and `second`, get them as arguments.
* You can assume that the caller is passing the right types of values -- integers for `first` and `second`, and a string for `operator`.
