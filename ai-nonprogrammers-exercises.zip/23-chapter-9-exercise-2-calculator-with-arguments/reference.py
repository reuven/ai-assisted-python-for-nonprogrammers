def calc(first, operator, second):
    if operator == '+':
        result = first + second
    elif operator == '-':
        result = first - second
    else:
        result = '(unknown)'

    print(f'{first} {operator} {second} = {result}')
