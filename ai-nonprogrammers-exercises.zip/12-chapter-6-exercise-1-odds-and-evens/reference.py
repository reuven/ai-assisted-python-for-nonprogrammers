odds = 0
evens = 0
numbers = [2, 3, 4, 5]

for one_number in numbers:
    if one_number % 2 == 1:
        odds += one_number
        print(f'{one_number} is odd; odds is now {odds}')
    else:
        evens += one_number
        print(f'{one_number} is even; evens is now {evens}')

print(f'odds = {odds}')
print(f'evens = {evens}')
