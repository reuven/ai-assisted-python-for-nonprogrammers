. Define two variables, `odds` and `evens`, both to be 0.
. Define a list, `numbers`, containing any integers you want. Make sure that it contains some evens and some odds.
. Iterate over the list, one number at a time.
.. If the number is even, add it to `evens`.
.. If the number is odd, add it to `odds`.
. Print the values of both `odds` and `evens`.

For example, if `numbers` is `[2, 3, 4, 5]`, then running the program should output:

```
odds: 8
evens: 6
```
