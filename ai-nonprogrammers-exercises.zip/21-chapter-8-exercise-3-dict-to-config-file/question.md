Earlier, you saw how to read data from a text file and turn it into an in-memory data structure. In this exercise, you'll take a dict in memory and write it to a text file on disk.

Here is what you need to implement for this exercise:

- Define a dictionary in which the keys and values are a combination of strings and integers.
- Using `with`, write the contents of the dict to a text file. Each line of the file should contain one key-value pair, separated by `=`, as in `a=10`.
- When you're done, look at the file and check that it matches the dictionary.
