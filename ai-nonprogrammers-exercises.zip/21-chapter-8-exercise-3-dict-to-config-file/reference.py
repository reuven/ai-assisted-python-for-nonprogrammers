d = {'a':10, 'b':20, 'c':30}

with open('pairs.txt', 'w') as f:
    for key, value in d.items():
        f.write(f'{key}={value}\n')
