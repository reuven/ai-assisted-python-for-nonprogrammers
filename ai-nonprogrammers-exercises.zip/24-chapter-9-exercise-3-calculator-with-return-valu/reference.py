def calc(first, operator, second):
    if operator == '+':
        result = first + second
    elif operator == '-':
        result = first - second
    else:
        result = '(unknown)'

    return f'{first} {operator} {second} = {result}'

for number in range(5):
    for operator in '+-':
        result = calc(number, operator, number + 10)
        print(result)
