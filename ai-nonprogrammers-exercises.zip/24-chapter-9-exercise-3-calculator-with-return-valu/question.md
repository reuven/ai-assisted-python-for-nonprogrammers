For the final exercise in this chapter, you'll again modify `calc`. This time, you'll change it to return a string value, rather than print that value on the screen. You'll then invoke the function a number of times inside of a `for` loop.

* Modify the `calc` program one final time, such that it returns a string value rather than print it.
* Now use a `for` loop to invoke `calc` 10 times, each time with different numbers and operators.
* Print the result of each invocation on the screen.
