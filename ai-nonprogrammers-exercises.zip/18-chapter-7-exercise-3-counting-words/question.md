* Define an empty dict, `counts`.
* Ask the user repeatedly to enter a text string. We can assume that the string will contain all lowercase letters and no punctuation or emojis.
* If the user enters an empty string, or one containing only whitespace, then stop asking.
* Go through each word in the user's input.
** If the word is already a key in `counts`, then increment its count by 1.
** If the word doesn't yet appear in `counts`, then add the key (the word) and value (1).
* After finishing with the user's input, print each word and its count on a separate line.

For example:

```
Enter text: this is the first run of this program
Enter text: the second run will undoubtedly be even better
Enter text: this is very exciting
Enter text:

this: 3
is: 2
the: 2
first: 1
run: 2
of: 1
program: 1
second: 1
will: 1
undoubtedly: 1
be: 1
even: 1
better: 1
very: 1
exciting: 1
```
