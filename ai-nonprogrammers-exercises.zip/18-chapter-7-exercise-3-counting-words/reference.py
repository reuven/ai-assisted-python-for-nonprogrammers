counts = {}

while True:
    text = input('Enter text: ').strip()

    if text == '':
        break

    for one_word in text.split():
        if one_word in counts:    
            counts[one_word] += 1 
        else:
            counts[one_word] = 1  

for key, value in counts.items(): 
    print(f'{key}: {value}')      
