* Define a dict with three keys, `'vowels'`, `'digits'`, and `'others'`. The value for each key should be 0.
* Ask the user to enter some text, and assign it to the variable `text`.
* Go through the string, one character at a time.
** Each time you encounter a vowel (a, e, i, o, or u), add 1 to the value for `'vowels'`.
** Each time you encounter a digit (0-9), add 1 to the value for `'digits'`.
** In all other cases, add 1 to the value for `'others'`. This includes punctuation and whitespace characters.
* Print the entire dictionary on the screen.
