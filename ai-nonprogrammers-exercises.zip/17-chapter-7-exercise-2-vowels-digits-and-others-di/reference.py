counts = {'vowels': 0, 'digits': 0, 'others': 0}

text = input('Enter text: ').strip()

for one_character in text.lower():
    if one_character in 'aeiou':
        counts['vowels'] += 1
    elif one_character.isdigit():
        counts['digits'] += 1
    else:
        counts['others'] += 1

print(counts)
