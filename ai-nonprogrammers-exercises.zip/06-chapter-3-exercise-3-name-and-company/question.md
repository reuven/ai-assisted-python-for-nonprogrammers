In this exercise, you'll use a combination of conditional code and boolean operators (`and`, `or`, and `not`) to give an appropriate greeting to someone based on their name and where they work.

* Define two variables, `my_name` and `my_company`, populating them with two text strings -- your name, and where you work
* Ask the user to enter their name, and store it in a variable, `user_name`
* Ask the user to enter the name of their company, and store it in a variable, `user_company`
* Based on the user's answers, print one of four greetings:
** If the name and company are the same as yours, greet yourself ("You must be me!")
** If the name is the same as yours, but the company is not, compliment the name but be snarky about the company
** If the company is the same as yours, but the name is not, greet your colleague
** If neither of the user's inputs matches yours, then be snarky toward both their name and company
