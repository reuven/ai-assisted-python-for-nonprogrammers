my_name = 'Reuven'
my_company = 'LernerPython'

user_name = input('Enter your name: ')
user_company = input('Enter your company: ')

if user_name == my_name and user_company == my_company:
    print('Hey, you must be me!')
elif user_name == my_name:
    print('Great name, but terrible employer!')
elif user_company == my_company:
    print(f'Greetings, {user_name}, my colleague!')
else:
    print('Your name and company are both terrible!')
