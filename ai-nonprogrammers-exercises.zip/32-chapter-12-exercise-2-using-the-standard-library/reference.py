from pathlib import Path
from collections import Counter

words = Counter()
dirname = input('Enter directory name: ').strip()

for one_filename in Path(dirname).glob('*.txt'):
    with one_filename.open() as f:
        print(one_filename.name)
        for one_line in f:
            words += Counter(one_line.split())

c = Counter(words)
for word, frequency in words.most_common(10):
    print(f'{word}: {frequency}')
