In this exercise, you will find which words appear most frequently in a directory of text files. You'll be aided by both `pathlib` and by `collections.Counter`.

. Define an empty list, `words`. This list will grow over the course of the program to include all of the words, from all of the files, you read through.
. Ask the user to enter a directory name.
. Use `glob` to get the text files (i.e., files ending with `'.txt'`) in this directory. Note that giving a directory name will not be sufficient; you need to give the full pattern, with both the directory name and `'*.txt'`.
. Go through each filename, and if it is a regular file, open it. Print the filename, so that the user gets a status update.
. Go through each line in the file. Break the line into a list of words (strings), and add them to `words`.
. When the program has gone through all of the text files, create a `Counter` object based on `words`.
. Use the `most_common` method to display the 10 most common words in these files, and how many times each appeared.
