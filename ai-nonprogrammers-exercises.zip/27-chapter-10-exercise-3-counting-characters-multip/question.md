In the previous exercise, you wrote `count_chars`, a function that took a filename and `to_count`, a string containing the characters you wanted to count. The function returned two values, the total count and a dictionary indicating how many times each character in `to_count` appeared.

You'll now modify the function such that the caller can pass more than one filename. The function should total the counts for all of the files.
