def count_chars(to_count, *args):
    total = 0
    counts = {}

    for one_character in to_count:
        counts[one_character] = 0

    for one_filename in args:                   # loop over filenames
        print(f'Processing {one_filename}...')
        with open(one_filename) as f:
            for one_line in f:                  # loop over lines
                for one_character in one_line:  # loop over chars
                    if one_character in counts:
                        counts[one_character] += 1
                        total += 1

    return total, counts
