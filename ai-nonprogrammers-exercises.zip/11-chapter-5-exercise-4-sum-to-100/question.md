In this exercise, you'll ask the user to enter numbers, adding them to a running total. When the total reaches 100 or more, the program stops.

. Set `total` to 0.
. Repeatedly ask the user to enter a number.
. If the user enters a non-number, then scold them and let them try again.
. Add the user's entered number to `total`. Print the current `total`.
. When `total` is 100 or more, then stop asking and print the final `total`.

Example:

```
Enter a number: 30
    total is 30
Enter a number: 20
    total is 50
Enter a number: hello
    hello is not a number; try again
Enter a number: 80
    total is 130
Final total is 130
```
