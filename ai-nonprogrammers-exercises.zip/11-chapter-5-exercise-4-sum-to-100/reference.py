total = 0

while total < 100:
    text = input('Enter a number: ').strip()

    if not text.isdecimal():
        print(f'{text} is not a number; try again')
        continue

    total += int(text)
    print(f'total is {total}')

print(f'Final total is {total}')
