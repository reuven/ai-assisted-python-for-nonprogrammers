name = 'Reuven'
city = 'Modiin'

print('Hello, ' + name + ' from ' + city + '!')
