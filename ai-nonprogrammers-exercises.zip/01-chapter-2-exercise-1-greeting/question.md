For this exercise, assign your name to the `name` variable and the city in which you reside to the `city` variable. Using these two variables, display a simple greeting on the computer screen.
