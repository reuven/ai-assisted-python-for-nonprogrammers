total = 0
text = input('Enter text: ').strip()

for one_character in text:
    if one_character == '.':
        break

    if not one_character.isdecimal():
        print(f'{one_character} is not a digit; ignoring')
        continue

    total += int(one_character)
    print(f'Added {one_character}; total is now {total}')

print(f'total = {total}')
