In this exercise, you will use `for`, along with `break` and `continue`, to sum the digits that a user enters in a string.

1. Define the variable `total` to be 0.
2. Ask the user to enter a string containing digits and non-digits. Assign it to the variable `text`.
3. Go through each character in `text`:
    - If the character is a period (`'.'`), then stop the loop and print `total`.
    - If the character is a non-digit, then tell the user it is being ignored.
    - If the character is a digit, then add its value to `total`, printing the updated `total`.
4. Print `total`.

For example, here is a sample run of the program including both the program's output and the user's input on the first line:

```
Enter text: 12ab3.4
Added 1; total is now 1
Added 2; total is now 3
a is not a digit; ignoring
b is not a digit; ignoring
Added 3; total is now 6
total = 6
```
