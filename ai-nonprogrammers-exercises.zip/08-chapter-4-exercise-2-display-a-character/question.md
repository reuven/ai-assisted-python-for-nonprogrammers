In this exercise, you will ask the user to enter a word. You will also ask the user to enter an index. Assuming the index is numeric and within the word's boundaries, display the index, word, and character.

* Ask the user to enter a word.
* Ask the user to enter a numeric index.
* If the index is non-numeric, give the user an error message.
* If the index is less than 0, give the user an error message.
* If the index is beyond the word's bounds, give the user an error message.
* Assuming all is well, print the index, word, and character.
