word = input('Enter a word: ').strip()
index_text = input('Enter an index: ').strip()

if index_text.isdecimal():
    index = int(index_text)

    if index < 0:
        print('Index is negative; ignoring')
    elif index >= len(word):
        print('Index is too high; ignoring')
    else:
        print(f'Index {index} in {word} is {word[index]}')
else:
    print(f'Index {index_text} is not numeric; ignoring')
