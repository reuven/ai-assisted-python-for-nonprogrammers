total = 0
text = input('Enter a sentence: ').strip()

for one_word in text.split():
    if one_word[0] == one_word[0].upper():
        total += 1

print(f'total = {total}')
