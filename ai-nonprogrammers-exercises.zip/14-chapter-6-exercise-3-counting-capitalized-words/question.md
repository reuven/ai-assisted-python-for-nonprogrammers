In this exercise, you'll ask the user to enter a sentence. You will then count the number of capitalized words (i.e., words that start with a capital letter) in the sentence, printing that number on the screen.

* Define a variable, `total`, to be 0.
* Ask the user to enter some text, and assign it to the variable `text`. We can assume that the user will only enter words, without any punctuation.
* Go through each word in the sentence, one at a time.
* If the first letter in the word is capitalized, then add 1 to `total`. Ignore capital letters that aren't at the start of a word.
* Print the value of `total`.

Example:

```
Enter a sentence: My name is Reuven
total is 2
```
