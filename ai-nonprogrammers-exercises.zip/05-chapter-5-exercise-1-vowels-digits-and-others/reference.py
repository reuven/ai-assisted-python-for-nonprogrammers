vowels = 0
digits = 0
others = 0

text = input('Enter text: ').strip()

for one_character in text.lower():
    if one_character in 'aeiou':
        vowels += 1
    elif one_character.isdecimal():
        digits += 1
    else:
        others += 1

print(f'{vowels=}')
print(f'{digits=}')
print(f'{others=}')
