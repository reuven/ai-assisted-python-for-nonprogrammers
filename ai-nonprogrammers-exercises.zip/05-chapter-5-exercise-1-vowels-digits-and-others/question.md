In this exercise, you will ask the user to enter some text. You'll then use a `for` loop to go through the characters in that string, counting the number of vowels, the number of digits, and the number of others.

* Define three variables, `vowels`, `digits`, and `others`, assigning them all the integer 0.
* Ask the user to enter some text, and assign it to the variable `text`.
* Go through the string, one character at a time.
** Each time you encounter a vowel (a, e, i, o, or u), add 1 to `vowels`.
** Each time you encounter a digit (0-9), add 1 to `digits`.
** In all other cases, add 1 to `others`. This includes punctuation and whitespace characters.
* Print the values of `vowels`, `digits`, and `others` on the screen.

Example:

```
Enter text: hello!! 123

vowels: 2
digits: 3
others: 6
```
