In the previous exercise, you counted the number of capitalized words that the user entered. In this exercise, you'll collect the capitalized words themselves, printing them for the user.

* Define a variable, `output`, to be an empty list, `[]`.
* Ask the user to enter some text, and assign it to the variable `text`. We can assume that the user will only enter words, without any punctuation.
* Go through each word in the sentence, one at a time.
* If the first letter in the word is capitalized, then append it to `output`. Ignore capital letters that aren't at the start of a word.
* Using `output`, print all of the capitalized words in the sentence, separated by commas.

Example:

```
Enter a sentence: My name is Reuven
My, Reuven
```
