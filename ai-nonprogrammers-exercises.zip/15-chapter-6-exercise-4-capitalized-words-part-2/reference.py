output = []

text = input('Enter a sentence: ').strip()

for one_word in text.split():
    if one_word[0] == one_word[0].upper():
        output.append(one_word)

print(', '.join(output))
