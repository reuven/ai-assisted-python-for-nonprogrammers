Every decimal number can be expanded to be the sum of numbers multiplied by a power of 10. For example, the number 2468 can be rewritten as:

```
2 * 10 ** 3
4 * 10 ** 2
6 * 10 ** 1
8 * 10 ** 0
```

Notice that you can calculate each power of 10 using Python's `**` operator. Also notice that the ones digit is still multiplied by a power of 10, but that would be 10 to the zeroth power (i.e., `10 ** 0`), which is 1.

Your challenge:

. Ask the user to enter a string containing only digits.
. If the string contains any non-digits, give an error message and stop.
. Go through each digit, printing it in the preceding format, with the digit multiplied by the appropriate power of 10.
