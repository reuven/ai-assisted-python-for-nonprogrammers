text = input('Enter a number: ').strip()

if text.isdecimal():
    for index, one_digit in enumerate(text):
        print(f'{one_digit} * 10 ** {len(text) - index - 1}')
else:
    print(f'Sorry, {text} contains non-digits; stopping.')
