first = 123
second = 456

total = first + second

print(total)
