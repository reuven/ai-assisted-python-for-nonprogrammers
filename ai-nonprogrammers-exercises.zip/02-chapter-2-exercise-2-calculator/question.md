In this exercise, you'll use your expensive computer to do the job of a cheap calculator.

Assign one integer (whole number) to the variable `first` and a second one to the variable `second`. Add these together, and put the result in the variable `total`. Print the value of `total`.
