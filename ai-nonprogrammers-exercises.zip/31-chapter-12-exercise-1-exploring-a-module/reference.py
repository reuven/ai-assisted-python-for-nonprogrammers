import math

print(len(dir(math)))

non_underscore_counter = 0
for one_name in dir(math):
    if one_name[0] != '_' and one_name[-1] != '_':
        non_underscore_counter += 1
print(non_underscore_counter)

radius = input('Enter radius: ')

area = math.pi * int(radius) ** 2
print(area)

large_number = input('Enter a large number: ').strip()
print(math.isqrt(int(large_number)))

print(11111 ** 2)

print(11112 ** 2)
