In this exercise, you will explore the `math` module in Python's standard library. Along the way, you'll not only learn about its functionality, but also how to learn about a new module.

This exercise involves very little coding, but a fair amount of exploring and playing:

. Import the `math` module, from Python's standard library.
. How many names are defined? How many names that do _not_ start or end with an underscore (`'_'`) does it define?
. Ask the user to enter the radius of a circle. Print the area of that circle, given that the area can be calculated as the square of the radius times `math.pi`.
. Ask the user to enter a large number. Using the module's documentation, find the function the calculates the integer square root of a number. (That is, the square root without any fractional part.) Calculate the integer square root of the user's input.
