from roman_numerals import RomanNumeral
rn1 = RomanNumeral.from_string(input('Enter first Roman numeral: ').strip())

rn2 = RomanNumeral.from_string(input('Enter second Roman numeral: ').strip())

total = int(rn1) + int(rn2)

print(f'{rn1} + {rn2} = {RomanNumeral(total)}')
