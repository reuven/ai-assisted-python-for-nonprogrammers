def count_chars(filename, to_count='aeiou'):
    total = 0
    counts = {}

    for one_character in to_count:
        counts[one_character] = 0

    with open(filename) as f:
        for one_line in f:
            for one_character in one_line:
                if one_character in counts:
                    counts[one_character] += 1
                    total += 1

    return total, counts
