In this exercise, you'll write a function, `count_chars`, that counts the number of characters in a file. By default, it'll count the number of vowels -- but by passing a second, optional argument, you'll be able to count other characters instead.


* Write a function, `count_chars`, which takes two arguments:
** The first, `filename`, is a string, the name of a text file.
** The second, `to_count`, is also a string, the characters that should be counted. By default, this will be the vowels, `'aeiou'`.
* The function should iterate over the file, one line at a time.
* Within each line, it should then iterate over each character, one at a time.
* The function returns a 2-element tuple:
** The first element of the returned tuple is an integer, the total count of matches found.
** The second element of the returned tuple is a dict, whose keys are the characters in `to_count`, and whose values are integers, the number of times each character appears in the file.


Here are two examples of invoking the function, and then the output:

```
count_chars('passwd.txt')
(2106, {'a': 551, 'e': 701, 'i': 380, 'o': 268, 'u': 206})

count_chars('passwd.txt', 'abcde')
(1840, {'a': 551, 'b': 219, 'c': 154, 'd': 215, 'e': 701})
```
