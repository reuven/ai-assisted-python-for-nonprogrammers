total = 0
filename = input('Enter a filename: ').strip()
f = open(filename)

for one_line in f:
    total += len(one_line)

f.close()
print(f'Total size: {total}')
