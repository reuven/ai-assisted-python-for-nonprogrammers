In this exercise, you'll calculate the size -- that is, the number of characters -- in a file and print it on the screen. You will probably want to use one of the files that comes in the zipfile you downloaded earlier.

- Ask the user to enter the name of a file, and assign it to `filename`.
- Set `total` to 0.
- Iterate through the file, adding the length of the current line -- counting all characters, including whitespace and punctuation -- to `total`
- When you're done iterating over the lines of the file, print `total`

Here is an example run of the program, using the _passwd.txt_ file from the zipfile:

```
Enter a filename: passwd.txt
Total size: 9064
```
