# AI-Assisted Python for Nonprogrammers: exercises

34 exercises, in course order. Each folder holds one exercise:

- `question.md`: the exercise as students see it
- `reference.py`: the reference solution (instructor's answer)
- `meta.toml`: title, difficulty, and the data files the exercise uses
- any data files the exercise reads, next to the question

The layout matches the practice system's bulk-import format. `display_id` and
`extra_packages` in `meta.toml` are extra keys that the importer ignores.
