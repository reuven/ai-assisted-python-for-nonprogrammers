In this exercise, you will generate a new, random password using four pools of characters -- lowercase letters, uppercase letters, digits, and punctuation. The user will decide how many random characters will be chosen from each pool. The program will then put those randomly selected characters together into a new password.

* From the `string` module, load several names:
** `ascii_lowercase` (aliased to `lc`)
** `ascii_uppercase` (aliased to `uc`)
** `digits` (no alias)
** `punctuation` (aliased to `punc`)
* From `random`, load:
** `shuffle` (aliased to `shuf`)
** `choices` (no alias)
* Define `pw_characters`, an empty list.
* Ask the user, in order:
** How many lowercase letters do they want?
** How many uppercase letters do they want?
** How many digits do they want?
** How many punctuation characters do they want?
* Using `random.choices`, retrieve the appropriate number of characters from each source string, and add to `pw_characters`.
* Invoke `random.shuffle` on `pw_characters` to mix them up.
* Use `str.join` to turn the list into a string
* Print the resulting password.
