from string import ascii_lowercase as lc, ascii_uppercase as uc
from string import digits, punctuation as punc
from random import shuffle as shuf, choices

pw_characters = []
lc_number = input('How many lowercase letters? ').strip()
uc_number = input('How many uppercase letters? ').strip()
d_number = input('How many digits? ').strip()
s_number = input('How many symbols? ').strip()

pw_characters += choices(lc, k=int(lc_number))
pw_characters += choices(uc, k=int(uc_number))
pw_characters += choices(digits, k=int(d_number))
pw_characters += choices(punc, k=int(s_number))

shuf(pw_characters)
pw = ''.join(pw_characters)
print(pw)
