In this exercise, you will write a short program that uses the `rich` module to print some text in color. 

The book's version of the exercise asks you to create a `uv` project, but that isn't possible in this Web-based practice system. Instead, just use `rich` to print some colorized text.
