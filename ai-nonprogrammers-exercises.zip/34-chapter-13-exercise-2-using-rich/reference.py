import rich

def main():
    rich.print("[blue]Hello[/blue] [yellow]from[/yellow] [green]userich[/green]!")

main()
