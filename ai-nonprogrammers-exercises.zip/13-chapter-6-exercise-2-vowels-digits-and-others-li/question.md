* Define three variables, `vowels`, `digits`, and `others`. Assign the empty list `[]` to each of them.
* Ask the user to enter some text, and assign it to the variable `text`.
* Go through the string, one character at a time.
** Each time you encounter a vowel (a, e, i, o, or u), append the character to `vowels`.
** Each time you encounter a digit (0-9), append the character to `digits`.
** In all other cases, append the character to `others`. This includes punctuation and whitespace characters.
* Print the values of `vowels`, `digits`, and `others` on the screen.

Example:

```
Enter text: hello!! 123

vowels: ['e', 'o']
digits: ['1', '2', '3']
others: ['h', 'l', 'l', '!', '!', ' ']
```
