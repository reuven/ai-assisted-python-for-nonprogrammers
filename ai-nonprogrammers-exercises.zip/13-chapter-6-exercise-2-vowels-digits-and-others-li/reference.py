vowels = []
digits = []
others = []

text = input('Enter text: ').strip()

for one_character in text.lower():
    if one_character in 'aeiou':
        vowels.append(one_character)
    elif one_character.isdecimal():
        digits.append(one_character)
    else:
        others.append(one_character)

print(f'{vowels=}')
print(f'{digits=}')
print(f'{others=}')
